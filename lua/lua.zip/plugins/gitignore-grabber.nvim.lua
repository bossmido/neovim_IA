-- Plugin: antonk52/gitignore-grabber.nvim
-- Installed via store.nvim

return {
    "antonk52/gitignore-grabber.nvim",
    event = "VeryLazy"
}