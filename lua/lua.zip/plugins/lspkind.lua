
return {
    "onsails/lspkind.nvim"
,lazy=false
}
