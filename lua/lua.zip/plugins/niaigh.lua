return { 'glacambre/firenvim', build = ":call firenvim#install(0)" }
