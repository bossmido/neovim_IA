-- Plugin: nvim-tree/nvim-web-devicons
-- Installed via store.nvim

return {
    "nvim-tree/nvim-web-devicons",
    opts = {}
}