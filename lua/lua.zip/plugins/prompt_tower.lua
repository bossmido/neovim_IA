return {
  'kylesnowschwartz/prompt-tower.nvim',
cmd={
  "PromptTowerGenerateContext",
  "PromptTowerSelectFiles",
  "PromptTowerFeedToAI",
  "PromptTowerToggleWindow"
},
  config = function()

  end,
}
