return {
  enable = false,
  -- "kevinhwang91/nvim-bqf",
  -- ft = "qf",
  "stevearc/quicker.nvim",
  event = "FileType qf",
  opts = {},
}
