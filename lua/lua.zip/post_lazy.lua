--fix le plus important.l'encodage
local client = vim.lsp.get_clients({ bufnr = 0 })[1]
if client then
  local params = vim.lsp.util.make_position_params(0, client.offset_encoding or "utf-16")
  -- use `params` here
end
--------------------------------------------------------------------------
local luasnip = require("luasnip")

luasnip.config.set_config({
    -- Use bordered windows with rounded corners
    ext_opts = {
        [require("luasnip.util.types").choiceNode] = {
            active = {
                virt_text = { { "●", "GruvboxGreen" } }, -- or other marker
                hl_group = "Visual",
                -- set window options for floating windows:

                winhighlight = "Normal:Normal,FloatBorder:FloatBorder",
                border = "rounded",
            },
        },
    },
})
-------------------------------------------------------------------------
require("notify").setup({
    -- Make sure stages support multiline
    stages = "fade_in_slide_out",
    -- or try "slide" or "fade"
    max_width = 110,    -- adjust width if needed
    max_height = 50000, -- adjust height if needed
})




local capabilities = vim.lsp.protocol.make_client_capabilities()

-- If using nvim-cmp
local ok, cmp_nvim_lsp = pcall(require, "cmp_nvim_lsp")
if ok then
    capabilities = cmp_nvim_lsp.default_capabilities(capabilities)
end

-- Fix offsetEncoding for clangd
-----------------------------------------------------------------------

--------------------------------------------------------------------------
--
--
-- local module_appelé = "blick.cmp"
-- local ok, mod = pcall(require, module_appelé)
-- if ok then
--     local capabilities = require(module_appelé).default_capabilities()
--
--     require('lspconfig').clangd.setup({
--         capabilities = capabilities,
--         on_attach = function(client, bufnr)
--             -- optional debug
--         end,
--     })
-- else
--     -- module does not exist or failed to load
-- end
-- -------------------------------------------------------------------

require("copilot").setup({

    suggestion = { enabled = false },

    panel = { enabled = false },
})
-----------------------------------------------------------------------
vim.lsp.config("texlab", {
  settings = {
      texlab = {
          build = {
              onSave = true,
          },
      },
  },
})
