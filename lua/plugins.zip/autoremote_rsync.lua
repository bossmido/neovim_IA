return {"gorillamoe/AutoRemoteSync.nvim",ft={"html","js","css"}} 
