return { "MagicDuck/grug-far.nvim", cmd = "GrugFar" }
