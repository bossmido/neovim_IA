
return {

    -- Mason (LSP installer)
    {
        "williamboman/mason.nvim",
        build = ":MasonUpdate",
        config = true,
    },

    -- Mason LSP Config
    {
        "williamboman/mason-lspconfig.nvim",
        event = "BufReadPost",
        dependencies = {
            "williamboman/mason.nvim",
            "neovim/nvim-lspconfig",
            "brymer-meneses/grammar-guard.nvim",
        },
        config = function()
            require("mason-lspconfig").setup({
                ensure_installed = {
                    "rust_analyzer",
                    "clangd",
                    "pyright",
                    "vtsls",
                    "html",
                    "cssls",
                    "texlab",
                    "luau_lsp",
                    "emmet_ls",
                    "ltex_plus",
                    --                    "efm",
                },
                automatic_installation = true,
            })


            -- LSP setups
            local lspconfig = require("lspconfig")

-- lspconfig.harper_ls.setup{
-- --  cmd = { "harper_ls" },
--   filetypes = { "text","plaintext", "markdown", "tex" },  -- types de fichiers textes usuels pour correction
--   root_dir = lspconfig.util.root_pattern(".git", "."),
--   settings = {
--     language = "fr",  -- ou selon la clé que le serveur attend pour choisir la langue
--   },
--   on_attach = function(client, bufnr)
--     -- Optionnel : tu peux définir des raccourcis pour la correction ici
--   end,
-- }
local capabilities = vim.lsp.protocol.make_client_capabilities()
capabilities.offsetEncoding = { "utf-8" }
--    local capabilities = require("blink.cmp").get_lsp_capabilities()
 require('lspconfig').clangd.setup {
   capabilities = capabilities,
   cmd = { "clangd",  "--background-index",
    "--pch-storage=memory",
    "--limit-results=40",
    "--completion-style=detailed",
    "--header-insertion=never",
    "--ranking-model=heuristics",
    "--all-scopes-completion=false",
    "--clang-tidy=false",
    "--log=error",
    "-j=2" },
 }

require('lspconfig').lua_ls.setup {
    settings = {
        Lua = {
            runtime = {
                version = 'LuaJIT', -- Neovim uses LuaJIT
            },
            diagnostics = {
                globals = { 'vim' }, -- Tell the server that `vim` is a global
            },
            workspace = {
                library = vim.api.nvim_get_runtime_file("", true), -- Make the server aware of Neovim runtime files
                checkThirdParty = false,                           -- Optional: Avoid "missing third-party" prompts
            },
            telemetry = {
                enable = false, -- Optional: Disable telemetry
            },
        }
    }
}
lspconfig.ltex.setup{
  cmd = { "ltex-ls" },  -- chemin vers ltex-ls si pas dans PATH
  filetypes = { "tex", "markdown", "plaintext" }, -- fichiers texte à corriger
  settings = {
    ltex = {
      language = "fr",            -- forcer la langue française
      diagnosticSeverity = "information",
      enabled = { "fr" },         -- activer les règles françaises
      disabledRules = {},         -- liste des règles à désactiver si besoin
    },
  },
}


                        lspconfig.ltex.setup{
                            cmd = { "ltex-ls" },  -- chemin vers ltex-ls si pas dans PATH
                            filetypes = { "tex", "markdown", "plaintext" }, -- fichiers texte à corriger
                            settings = {
                                ltex = {
                                    language = "fr",            -- forcer la langue française
                                    diagnosticSeverity = "information",
                                    enabled = { "fr" },         -- activer les règles françaises
                                    disabledRules = {},         -- liste des règles à désactiver si besoin
                                },
                            },
                        }






                        -- Try texlab first (usually more stable)
                        local texlab_cmd = vim.fn.executable('texlab') == 1 and 'texlab' or nil
                        local ltex_cmd = vim.fn.executable('ltex-ls') == 1 and 'ltex-ls' or nil

                        if texlab_cmd then
                            lspconfig.texlab.setup({
                                cmd = { texlab_cmd },
                                filetypes = { "tex", "plaintex", "bib" },
                            })
                        elseif ltex_cmd then
                            -- lspconfig.ltex.setup({
                                --     cmd = { ltex_cmd },
                                --     filetypes = { "tex", "plaintex", "bib", "markdown" },
                                --     settings = {
                                    --         ltex = {
                                        --             language = "en-US",
                                        --         }
                                        --     }
                                        -- })
                                    else
                                        vim.notify("No LaTeX LSP server found. Install texlab or ltex-ls", vim.log.levels.WARN)
                                    end

                                    lspconfig.vtsls.setup({
                                        cmd = { "vtsls", "--stdio" },
                                        filetypes = { "javascript", "typescript", "vue" },
                                        root_dir = lspconfig.util.root_pattern("tsconfig.json", "jsconfig.json", ".git"),
                                        settings = {
                                            typescript = {
                                                implicitProjectConfig = {
                                                    checkJs = true,
                                                },
                                            },
                                            javascript = {
                                                implicitProjectConfig = {
                                                    checkJs = true,
                                                },
                                            },
                                            vtsls = {
                                                experimental = {
                                                    completion = {
                                                        enableServerSideFuzzyMatch = true,
                                                    },
                                                },
                                            },
                                        },
                                    })

                                    lspconfig.emmet_ls.setup({
                                        filetypes = {
                                            "html", "css", "typescriptreact", "javascriptreact", "jsx", "tsx",
                                        },
                                        init_options = {
                                            html = {
                                                options = {
                                                    ["bem.enabled"] = true,
                                                },
                                            },
                                        },
                                    })

                                    lspconfig.html.setup({
                                        filetypes = { "htmldjango", "blade" },
                                    })


                        -- Lua config for Neovim runtime
                        lspconfig.lua_ls.setup({
                            settings = {
                                Lua = {
                                    diagnostics = {
                                        globals = { "vim" },
                                    },
                                    workspace = {
                                        library = vim.api.nvim_get_runtime_file("", true),
                                        checkThirdParty = false,
                                    },
                                    telemetry = { enable = false },
                                },
                            },
                        })
                    end,
                },
            }


