return
{
  "nvzone/minty",
  cmd = { "Shades", "Huefy" },
}
