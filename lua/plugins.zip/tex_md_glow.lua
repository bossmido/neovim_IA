return {"ellisonleao/glow.nvim", config = true, cmd = "Glow"}
