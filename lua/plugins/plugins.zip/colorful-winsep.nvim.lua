-- Plugin: nvim-zh/colorful-winsep.nvim
-- Installed via store.nvim
return {
    "nvim-zh/colorful-winsep.nvim",
    config = true,
    event = {"WinLeave"}
}
