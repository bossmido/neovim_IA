
return {


  -- Mason (LSP installer)
  {

    "williamboman/mason.nvim",
    build = ":MasonUpdate",
    config = true,

  },

  -- Mason + LSP config (new API)

  {
    "williamboman/mason-lspconfig.nvim",
    event = { "BufReadPre", "BufNewFile" },
    dependencies = {
      "williamboman/mason.nvim",
      "neovim/nvim-lspconfig",

      "brymer-meneses/grammar-guard.nvim",
    },
    config = function()
      local ok_mason, mason_lspconfig = pcall(require, "mason-lspconfig")
      if not ok_mason then

        vim.notify("mason-lspconfig not available", vim.log.levels.ERROR)
        return
      end

      mason_lspconfig.setup({
        ensure_installed = {
          "rust_analyzer",

          "clangd",
          "pyright",
          "vtsls",
          "html",
          "cssls",
          "texlab",
          "luau_lsp",

          "emmet_ls",

--          "ltex",
        },
        automatic_installation = true,
      })

      ---------------------------------------------------------------------
      -- Shared LSP capabilities
      ---------------------------------------------------------------------
      local capabilities = vim.lsp.protocol.make_client_capabilities()
      capabilities.offsetEncoding = { "utf-8" }

      local function start_server(cfg)
        if vim.fn.executable(cfg.cmd[1]) == 0 then
          vim.notify("Missing LSP binary: " .. cfg.cmd[1], vim.log.levels.WARN)
          return
        end
        vim.lsp.start(cfg)
      end

      ---------------------------------------------------------------------
      -- clangd
      ---------------------------------------------------------------------
      start_server(vim.lsp.config({
        name = "clangd",
        cmd = {
          "clangd",

          "--background-index",
          "--pch-storage=memory",
          "--limit-results=40",
          "--completion-style=detailed",
          "--header-insertion=never",
          "--ranking-model=heuristics",

          "--all-scopes-completion=false",
          "--clang-tidy=false",
          "--log=error",
          "-j=2",
        },
        capabilities = capabilities,
        root_markers = { ".clangd", ".git" },

      }))



      ---------------------------------------------------------------------
      -- lua_ls


      ---------------------------------------------------------------------
      start_server(vim.lsp.config({
        name = "lua_ls",
        cmd = { "lua-language-server" },
        root_markers = { ".luarc.json", ".git" },

        settings = {
          Lua = {
            runtime = { version = "LuaJIT" },
            diagnostics = { globals = { "vim" } },
            workspace = {

              library = vim.api.nvim_get_runtime_file("", true),
              checkThirdParty = false,
            },
            telemetry = { enable = false },
          },
        },

      }))


      ---------------------------------------------------------------------
      -- texlab / ltex

      ---------------------------------------------------------------------
      if vim.fn.executable("texlab") == 1 then
        start_server(vim.lsp.config({
          name = "texlab",
          cmd = { "texlab" },
          filetypes = { "tex", "plaintex", "bib" },
        }))
      elseif vim.fn.executable("ltex-ls") == 1 then
        start_server(vim.lsp.config({
          name = "ltex",
          cmd = { "ltex-ls" },
          filetypes = { "tex", "markdown", "plaintext" },
          settings = {
            ltex = {
              language = "fr",

              diagnosticSeverity = "information",
            },

          },

        }))
      else
        vim.notify("No LaTeX LSP found (texlab or ltex-ls)", vim.log.levels.WARN)
      end

      ---------------------------------------------------------------------
      -- vtsls / tsserver

      ---------------------------------------------------------------------
      if vim.fn.executable("vtsls") == 1 then
        start_server(vim.lsp.config({

          name = "vtsls",
          cmd = { "vtsls", "--stdio" },

          filetypes = { "javascript", "typescript", "vue" },
          root_markers = { "tsconfig.json", "jsconfig.json", ".git" },
          settings = {
            typescript = { implicitProjectConfig = { checkJs = true } },
            javascript = { implicitProjectConfig = { checkJs = true } },
            vtsls = {
              experimental = {

                completion = { enableServerSideFuzzyMatch = true },

              },
            },
          },
        }))
      elseif vim.fn.executable("tsserver") == 1 then
        vim.notify("Using tsserver fallback", vim.log.levels.INFO)
        start_server(vim.lsp.config({
          name = "tsserver",
          cmd = { "tsserver" },
          filetypes = { "javascript", "typescript", "vue" },
          root_markers = { "tsconfig.json", "jsconfig.json", ".git" },
        }))

      else
        vim.notify("No vtsls or tsserver found", vim.log.levels.WARN)
      end

      ---------------------------------------------------------------------
      -- emmet
      ---------------------------------------------------------------------
      if vim.fn.executable("emmet-ls") == 1 then

        start_server(vim.lsp.config({
          name = "emmet_ls",
          cmd = { "emmet-ls", "--stdio" },
          filetypes = { "html", "css", "typescriptreact", "javascriptreact", "jsx", "tsx" },
          init_options = {

            html = { options = { ["bem.enabled"] = true } },
          },
        }))
      end

      ---------------------------------------------------------------------
      -- html
      ---------------------------------------------------------------------

      if vim.fn.executable("vscode-html-language-server") == 1 then
        start_server(vim.lsp.config({
          name = "html",

          cmd = { "vscode-html-language-server", "--stdio" },
          filetypes = { "html", "htmldjango", "blade" },
        }))

      end
    end,
  },
}



